package com.chatbot.whatsapp.controller;

public class Message {

}
