package com.chatbot.whatsapp.controller;

import com.chatbot.whatsapp.service.ReplyService;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/message")
public class MessageController {
	
	@Autowired
	private ReplyService replyservice;
	
	
    @PostMapping("/receive")
    public ResponseEntity<String> receiveMessage(@RequestBody Message message) {
        DatabaseReference ref = FirebaseDatabase.getInstance()
            .getReference("messages")
            .push(); // creates a random unique ID

        ref.setValueAsync(message);
        return ResponseEntity.ok("📨 Message received and saved!");
    }
}