package com.chatbot.whatsapp.model;

public class Message {

}
