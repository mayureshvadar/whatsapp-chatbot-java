package com.chatbot.whatsappbot;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.InputStream;

@Component
public class FirebaseInitializer {
	
	@PostConstruct
	public void initfirebase() {
		try {
			InputStream serviceAccount =  getClass().getClassLoader().getResourceAsStream("firebase-key.json");
			if(FirebaseApp.getApps().isEmpty()) {
			FirebaseOptions options = FirebaseOptions.builder()
					.setCredentials(GoogleCredentials.fromStream(serviceAccount))
					.build();
			
			FirebaseApp.initializeApp(options);
			System.out.println("Firebase Initialized");
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		}
	}


