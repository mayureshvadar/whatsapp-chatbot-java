package com.chatbot.whatsappbot;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FirebaseTestController {

    @GetMapping("/write")
    public String writeData() {
        // logic here
        return "✅ Reply written!";
    }
}