package com.chatbot.whatsappbot;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class WebhookController {

	@PostMapping("/webhook")
	public ResponseEntity<String> receiveMessage(@RequestBody String Payload){
		System.out.println("Receive Message:/n" + Payload);
		return ResponseEntity.ok("EVENT_RECEIVE");
		
	}
	@GetMapping("/webhook")
	public ResponseEntity<String> verifyWebhook(
	        @RequestParam(name = "hub.mode") String mode,
	        @RequestParam(name = "hub.verify_token") String token,
	        @RequestParam(name = "hub.challenge") String challenge) {

	    String VERIFY_TOKEN = "mayuresh-bot"; // Must match the token you used in Meta Dashboard

	    if (mode != null && token != null && mode.equals("subscribe") && token.equals(VERIFY_TOKEN)) {
	        System.out.println("✅ Webhook verified successfully!");
	        return ResponseEntity.ok(challenge); // Sends the challenge back to Meta
	    } else {
	        System.out.println("❌ Webhook verification failed.");
	        return ResponseEntity.status(403).body("Verification failed");
	    }
	}
}

