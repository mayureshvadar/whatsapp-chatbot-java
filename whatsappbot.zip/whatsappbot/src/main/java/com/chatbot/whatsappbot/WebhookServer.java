package com.chatbot.whatsappbot;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.PrintWriter;
import java.time.LocalDateTime;
public class WebhookServer {

    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        server.createContext("/webhook", new WebhookHandler());
        server.setExecutor(null); // Use default executor
        server.start();
        System.out.println("✅ Server started at http://localhost:8080/webhook");
    }

    static class WebhookHandler implements HttpHandler {
       
    	private void logConversation(String from, String userMessage, String botReply) {
    	    try (FileWriter fw = new FileWriter("chatlog.txt", true);
    	         BufferedWriter bw = new BufferedWriter(fw);
    	         PrintWriter out = new PrintWriter(bw)) {

    	        out.println("[" + LocalDateTime.now() + "]");
    	        out.println("From: " + from);
    	        out.println("User: " + userMessage);
    	        out.println("Bot: " + botReply);
    	        out.println("----------------------------------");

    	    } catch (Exception e) {
    	        System.out.println(" Error writing to log: " + e.getMessage());
    	    }
    	}
    	
    	private void sendReplyToMockAPI(String to, String message) {
    	    try {
    	        URL url = new URL("https://webhook.site/https://webhook.site/0a415fc1-da8d-477d-bc82-33bbad2d6827"); // Replace with your actual URL
    	        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    	        conn.setRequestMethod("POST");
    	        conn.setRequestProperty("Content-Type", "application/json");
    	        conn.setDoOutput(true);

    	        String json = "{ \"to\": \"" + to + "\", \"message\": \"" + message + "\" }";
    	        byte[] out = json.getBytes(StandardCharsets.UTF_8);

    	        conn.getOutputStream().write(out);
    	        int responseCode = conn.getResponseCode();
    	        System.out.println(" Sent reply to mock API. Response code: " + responseCode);
    	    } catch (Exception e) {
    	        System.out.println(" Failed to send reply: " + e.getMessage());
    	    }
    	}
    	
    	@Override
        public void handle(HttpExchange exchange) {
            try {
                if ("GET".equals(exchange.getRequestMethod())) {
                    // ✅ Handle GET request for webhook verification
                    String query = exchange.getRequestURI().getQuery();
                    String challenge = query.split("hub.challenge=")[1];
                    String response = challenge;
                    exchange.sendResponseHeaders(200, response.length());
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                    System.out.println("✅ Webhook verified!");
                    return;
                }

                if ("POST".equals(exchange.getRequestMethod())) {
                    // 📩 Handle incoming POST messages
                    InputStream input = exchange.getRequestBody();
                    String body = new String(input.readAllBytes());

                    JSONObject json = new JSONObject(body);
                    JSONArray entry = json.getJSONArray("entry");
                    JSONObject change = entry.getJSONObject(0)
                                             .getJSONArray("changes")
                                             .getJSONObject(0)
                                             .getJSONObject("value");

                    if (change.has("messages")) {
                        JSONObject message = change.getJSONArray("messages").getJSONObject(0);
                        String from = message.getString("from");
                        String text = message.getJSONObject("text").getString("body");

                        // 🤖 Simple auto-reply logic
                        String reply;
                        if (text.equalsIgnoreCase("hi") || text.equalsIgnoreCase("hello")) {
                            reply = "Hey there!  How can I help you today?";
                        } else if (text.toLowerCase().contains("time")) {
                            reply = " The current server time is: " + java.time.LocalTime.now();
                        } else {
                            reply = " Sorry, I didn’t understand that. Try saying 'hi' or ask me the time!";
                        }

                        // 🖨️ Log incoming and reply
                        System.out.println(" Message from: " + from);
                        System.out.println(" Text: " + text);
                        System.out.println(" Auto-reply: " + reply);
                        sendReplyToMockAPI(from, reply);
                        logConversation(from, text, reply);

                    } else {
                        System.out.println(" No messages found in payload.");
                    }

                    String response = "EVENT_RECEIVED";
                    exchange.sendResponseHeaders(200, response.length());
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                } else {
                    // ⛔ Unsupported method
                    exchange.sendResponseHeaders(405, 0);
                    exchange.getResponseBody().close();
                    System.out.println(" Unsupported request method: " + exchange.getRequestMethod());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}