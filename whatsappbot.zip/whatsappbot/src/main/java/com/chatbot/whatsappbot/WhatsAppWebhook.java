package com.chatbot.whatsappbot;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

@WebServlet("/webhook")
public class WhatsAppWebhook extends HttpServlet {

    
    private static final String ACCESS_TOKEN = "YOUR_ACCESS_TOKEN";
    private static final String PHONE_NUMBER_ID = "YOUR_PHONE_NUMBER_ID";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String mode = req.getParameter("hub.mode");
        String token = req.getParameter("hub.verify_token");
        String challenge = req.getParameter("hub.challenge");

        if ("subscribe".equals(mode) && "your_verify_token".equals(token)) {
            resp.getWriter().print(challenge);
        } else {
            resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = req.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }

        String json = sb.toString();
        System.out.println("Incoming POST:\n" + json);
        handleMessage(json);
    }

    private void handleMessage(String json) {
        try {
            JsonObject body = JsonParser.parseString(json).getAsJsonObject();
            JsonObject message = body
                    .getAsJsonArray("entry").get(0).getAsJsonObject()
                    .getAsJsonArray("changes").get(0).getAsJsonObject()
                    .getAsJsonObject("value")
                    .getAsJsonArray("messages").get(0).getAsJsonObject();

            String from = message.get("from").getAsString();
            String text = message.getAsJsonObject("text").get("body").getAsString();

            System.out.println("From: " + from);
            System.out.println("Message: " + text);

            String reply = generateReply(text);
            System.out.println("Bot Reply: " + reply);

            sendReply(from, reply);

        } catch (Exception e) {
            System.err.println("Error parsing JSON or sending reply: " + e.getMessage());
        }
    }

    private String generateReply(String msg) {
        if (msg.equalsIgnoreCase("hi") || msg.equalsIgnoreCase("hello")) {
            return "Hey there! How can I assist you today?";
        } else if (msg.equalsIgnoreCase("bye")) {
            return "Goodbye! Have a great day.";
        } else {
            return "You said: " + msg;
        }
    }

    private void sendReply(String to, String message) {
        try {
            URL url = new URL("https://graph.facebook.com/v19.0/" + PHONE_NUMBER_ID + "/messages");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Authorization", "Bearer " + ACCESS_TOKEN);
            con.setRequestProperty("Content-Type", "application/json");
            con.setDoOutput(true);

            String jsonPayload = String.format(
                "{\"messaging_product\":\"whatsapp\",\"to\":\"%s\",\"text\":{\"body\":\"%s\"}}",
                to, message
            );

            try (OutputStream os = con.getOutputStream()) {
                os.write(jsonPayload.getBytes());
            }

            int responseCode = con.getResponseCode();
            System.out.println("API Response Code: " + responseCode);

        } catch (Exception e) {
            System.err.println("Error sending message: " + e.getMessage());
        }
    }
}