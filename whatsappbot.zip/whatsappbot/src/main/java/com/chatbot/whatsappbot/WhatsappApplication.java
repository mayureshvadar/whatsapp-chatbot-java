package com.chatbot.whatsappbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages={"com.chatbot.whatsapp.controller","com.chatbot.whatsappbot","com.chatbot.whatsappbot.service","com.chatbot.whatsappbot.model","com.chatbot.whatsapp"})
public class WhatsappApplication {
	
	public static void main(String [] args) {
		
		SpringApplication.run(WhatsappApplication.class, args); 
		
	}

}
